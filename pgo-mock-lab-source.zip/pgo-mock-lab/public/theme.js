// Applies the saved theme before the page paints, so there is no flash.
try{var t=localStorage.getItem("pgo-theme");if(t==="light"||t==="dark"||t==="sepia")document.documentElement.setAttribute("data-theme",t)}catch(e){}
